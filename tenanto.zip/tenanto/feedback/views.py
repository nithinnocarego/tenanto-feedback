

# feedback/views.py

from django.shortcuts import render, get_object_or_404, redirect
from .models import Feedback, Question

def index(request, feedback_id):
    feedback = get_object_or_404(Feedback, unique_id=feedback_id)
    return render(request, 'feedback/index.html', {
        'feedback': feedback
    })

def start_feedback(request):
    feedback_id = request.POST.get('feedback_id')
    feedback = get_object_or_404(Feedback, unique_id=feedback_id)
    return redirect('question', feedback_id=feedback_id, question_number=1)

def is_last_question(question_number):
    total_questions = Question.objects.count()
    return question_number == total_questions

def question(request, feedback_id, question_number):
    feedback = get_object_or_404(Feedback, unique_id=feedback_id)
    question = get_object_or_404(Question, question_number=question_number)
    last_question = is_last_question(question_number)
    total_questions = Question.objects.count()

    if request.method == 'POST':
        rating = request.POST.get('rating')
        setattr(feedback, f'question_{question_number}', rating)
        feedback.save()
        if last_question:
            return redirect('additional_comments', feedback_id=feedback_id)
        else:
            return redirect('question', feedback_id=feedback_id, question_number=question_number+1)

    return render(request, 'feedback/question.html', {
        'feedback': feedback,
        'question': question,
        'question_number': question_number,
        'is_last_question': last_question,
        'total_questions_range': range(1, total_questions + 1)
    })

def additional_comments(request, feedback_id):
    feedback = get_object_or_404(Feedback, unique_id=feedback_id)

    if request.method == 'POST':
        additional_comments = request.POST.get('additional_comments')
        re_rent = request.POST.get('re_rent') == 'yes'
        feedback.additional_comments = additional_comments
        feedback.re_rent = re_rent
        feedback.save()
        return redirect('thank_you', feedback_id=feedback_id)

    return render(request, 'feedback/additional_comments.html', {
        'feedback': feedback
    })


def thank_you(request, feedback_id):
    feedback = get_object_or_404(Feedback, unique_id=feedback_id)
    return render(request, 'feedback/thank_you.html', {
        'feedback': feedback
    })
