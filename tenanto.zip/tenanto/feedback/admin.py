# feedback/admin.py

from django.contrib import admin
from .models import Feedback, Question

admin.site.register(Feedback)
admin.site.register(Question)
