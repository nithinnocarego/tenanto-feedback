# feedback/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('feedback/<str:feedback_id>/', views.index, name='feedback_index'),
    path('start_feedback/', views.start_feedback, name='start_feedback'),
    path('question/<str:feedback_id>/<int:question_number>/', views.question, name='question'),
    path('additional_comments/<str:feedback_id>/', views.additional_comments, name='additional_comments'),
    path('thank_you/<str:feedback_id>/', views.thank_you, name='thank_you'),
]
