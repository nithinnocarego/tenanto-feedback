from django.db import models

# Create your models here.
# feedback/models.py

from django.db import models

class Feedback(models.Model):
    unique_id = models.CharField(max_length=50, unique=True)
    landlord_name = models.CharField(max_length=100)
    tenant_name = models.CharField(max_length=100)
    tenant_address = models.CharField(max_length=200)
    question_1 = models.IntegerField(null=True, blank=True)
    question_2 = models.IntegerField(null=True, blank=True)
    question_3 = models.IntegerField(null=True, blank=True)
    question_4 = models.IntegerField(null=True, blank=True)
    question_5 = models.IntegerField(null=True, blank=True)
    question_6 = models.IntegerField(null=True, blank=True)
    question_7 = models.IntegerField(null=True, blank=True)
    question_8 = models.IntegerField(null=True, blank=True)
    additional_comments = models.TextField(null=True, blank=True)
    re_rent = models.BooleanField(null=True, blank=True)

    def __str__(self):
        return f"{self.tenant_name} - {self.unique_id}"

class Question(models.Model):
    question_number = models.IntegerField(unique=True)
    question_title = models.CharField(max_length=200)
    question_description = models.TextField()
    low_keyword = models.CharField(max_length=50, default='Bad')
    high_keyword = models.CharField(max_length=50, default='Good')

    def __str__(self):
        return f"Question {self.question_number}"
